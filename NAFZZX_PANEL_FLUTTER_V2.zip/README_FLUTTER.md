# NAFZZX PANEL — Flutter Edition

Ini adalah aplikasi Flutter (client) yang menggunakan backend Node.js asli di folder `backend/`. Backend tetap diperlukan karena menyimpan akun dan mengamankan API key/cookie AM-PREM.

## Menjalankan
1. Instal Flutter SDK dan Android toolchain.
2. Jalankan backend: masuk ke `backend/NAFZZX_PANEL_AMPREM_V2`, jalankan `npm install` lalu `npm start`. Konfigurasi `AM_API_KEY` dan `AM_SESSION_COOKIE` hanya di `server.js` backend.
3. Dari folder utama project: `flutter pub get`.
4. Jalankan `flutter run`.
5. Android emulator memakai default `http://10.0.2.2:3255`. Untuk HP fisik, isi alamat IP LAN/VPS backend di kolom alamat backend pada layar login, misalnya `http://192.168.1.10:3255`. Pastikan firewall mengizinkan port 3255. Untuk produksi gunakan HTTPS.

Login default backend: `Nafzzx` / `bilqis` (ganti sebelum deployment).

Catatan: ini mengubah antarmuka menjadi Flutter, bukan mengubah server Node.js menjadi Dart. Backend dipertahankan agar logika autentikasi dan integrasi AM-PREM tetap bekerja.
