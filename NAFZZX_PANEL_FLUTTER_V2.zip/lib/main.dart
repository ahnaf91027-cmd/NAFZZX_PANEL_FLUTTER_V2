import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

void main() => runApp(const NafzzxApp());

class NafzzxApp extends StatelessWidget {
  const NafzzxApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'NAFZZX PANEL', debugShowCheckedModeBanner: false,
    theme: ThemeData(colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF8B5CF6), brightness: Brightness.dark), useMaterial3: true, scaffoldBackgroundColor: const Color(0xFF09090F)),
    home: const LoginPage(),
  );
}

class Api {
  static String base = 'http://10.0.2.2:3255'; // Android emulator; edit for your server IP/domain
  static String? token;
  static Future<Map<String,dynamic>> request(String path,{String method='GET',Map<String,dynamic>? body}) async {
    final uri=Uri.parse('$base$path');
    final headers=<String,String>{'Content-Type':'application/json'};
    if(token!=null) headers['Authorization']='Bearer $token';
    final response = method=='POST' ? await http.post(uri,headers:headers,body:jsonEncode(body??{})).timeout(const Duration(seconds:25)) : method=='DELETE' ? await http.delete(uri,headers:headers).timeout(const Duration(seconds:25)) : await http.get(uri,headers:headers).timeout(const Duration(seconds:25));
    final data=jsonDecode(response.body);
    if(data is Map<String,dynamic>) return data;
    throw Exception('Respons server tidak valid');
  }
}

class LoginPage extends StatefulWidget { const LoginPage({super.key}); @override State<LoginPage> createState()=>_LoginPageState(); }
class _LoginPageState extends State<LoginPage> {
 final user=TextEditingController(text:'Nafzzx'), pass=TextEditingController(); bool busy=false, obscure=true; String? error;
 Future<void> login() async { setState((){busy=true;error=null;}); try { final r=await Api.request('/api/login',method:'POST',body:{'username':user.text.trim(),'password':pass.text}); if(r['success']==true){Api.token=r['token']; if(mounted) Navigator.pushReplacement(context,MaterialPageRoute(builder:(_)=>DashboardPage(userData:Map<String,dynamic>.from(r['user']??{}))));} else {setState(()=>error=r['message']??'Login gagal');} } catch(e){setState(()=>error='Tidak dapat terhubung ke backend. Periksa alamat server.');} finally{if(mounted)setState(()=>busy=false);} }
 @override Widget build(BuildContext context)=>Scaffold(body:Center(child:SingleChildScrollView(padding:const EdgeInsets.all(24),child:ConstrainedBox(constraints:const BoxConstraints(maxWidth:440),child:Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[const Icon(Icons.shield_moon_outlined,size:64,color:Color(0xFFA78BFA)),const SizedBox(height:18),const Text('NAFZZX PANEL',textAlign:TextAlign.center,style:TextStyle(fontSize:28,fontWeight:FontWeight.w900,letterSpacing:2)),const SizedBox(height:6),Text('AM-PREM • Flutter Edition',textAlign:TextAlign.center,style:TextStyle(color:Colors.grey.shade400)),const SizedBox(height:34),TextField(controller:user,decoration:const InputDecoration(labelText:'Username',prefixIcon:Icon(Icons.person_outline),border:OutlineInputBorder())),const SizedBox(height:14),TextField(controller:pass,obscureText:obscure,onSubmitted:(_)=>login(),decoration:InputDecoration(labelText:'Password',prefixIcon:const Icon(Icons.lock_outline),suffixIcon:IconButton(icon:Icon(obscure?Icons.visibility:Icons.visibility_off),onPressed:()=>setState(()=>obscure=!obscure)),border:const OutlineInputBorder())),if(error!=null) Padding(padding:const EdgeInsets.only(top:12),child:Text(error!,style:const TextStyle(color:Colors.redAccent))),const SizedBox(height:22),FilledButton(onPressed:busy?null:login,style:FilledButton.styleFrom(padding:const EdgeInsets.all(16)),child:busy?const SizedBox(height:20,width:20,child:CircularProgressIndicator(strokeWidth:2)):const Text('MASUK')),const SizedBox(height:14),TextField(decoration:const InputDecoration(labelText:'Alamat backend (opsional)',hintText:'http://192.168.1.10:3255',prefixIcon:Icon(Icons.link),border:OutlineInputBorder()),onSubmitted:(v){if(v.trim().isNotEmpty)Api.base=v.trim().replaceAll(RegExp(r'/$'),'');}),const SizedBox(height:8),Text('Pastikan backend Node.js berjalan. Jangan menaruh API key AM-PREM di aplikasi Flutter.',textAlign:TextAlign.center,style:TextStyle(fontSize:12,color:Colors.grey.shade500))])))));
}

class DashboardPage extends StatefulWidget { final Map<String,dynamic> userData; const DashboardPage({super.key,required this.userData}); @override State<DashboardPage> createState()=>_DashboardPageState(); }
class _DashboardPageState extends State<DashboardPage> {
 Map<String,dynamic> stats={}; String message=''; bool busy=false; final email=TextEditingController(), link=TextEditingController();
 Future<void> loadStats() async {try{final r=await Api.request('/api/stats');if(mounted)setState(()=>stats=r);}catch(_){if(mounted)setState(()=>message='Gagal mengambil statistik.');}}
 Future<void> action(String path,{Map<String,dynamic>? body}) async {setState(()=>busy=true);try{final r=await Api.request(path,method:'POST',body:body);setState(()=>message=r['message']??(r['success']==true?'Berhasil':'Permintaan gagal'));}catch(e){setState(()=>message='Permintaan gagal: periksa koneksi dan backend.');}finally{if(mounted)setState(()=>busy=false);}}
 @override void initState(){super.initState();loadStats();}
 Widget tile(String title,String subtitle,IconData icon,VoidCallback onTap)=>Card(child:ListTile(leading:CircleAvatar(child:Icon(icon)),title:Text(title,style:const TextStyle(fontWeight:FontWeight.bold)),subtitle:Text(subtitle),trailing:const Icon(Icons.chevron_right),onTap:onTap));
 Future<void> logout() async {try{await Api.request('/api/logout',method:'POST');}catch(_){} Api.token=null;if(mounted)Navigator.pushAndRemoveUntil(context,MaterialPageRoute(builder:(_)=>const LoginPage()),(_)=>false);}
 @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('NAFZZX PANEL'),actions:[IconButton(onPressed:loadStats,icon:const Icon(Icons.refresh)),IconButton(onPressed:logout,icon:const Icon(Icons.logout))]),body:RefreshIndicator(onRefresh:loadStats,child:ListView(padding:const EdgeInsets.all(16),children:[Container(padding:const EdgeInsets.all(20),decoration:BoxDecoration(gradient:const LinearGradient(colors:[Color(0xFF312E81),Color(0xFF6D28D9)]),borderRadius:BorderRadius.circular(20)),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('Halo, ${widget.userData['username']??'User'}',style:const TextStyle(fontSize:24,fontWeight:FontWeight.bold)),const SizedBox(height:6),Text('Role: ${widget.userData['role']??'-'}'),const SizedBox(height:16),Row(children:[Expanded(child:metric('Online', '${stats['onlineUsers']??'—'}')),if(stats.containsKey('totalUsers'))Expanded(child:metric('Total akun','${stats['totalUsers']}'))])])),const SizedBox(height:18),const Text('AM-PREM TOOLS',style:TextStyle(fontSize:13,fontWeight:FontWeight.bold,letterSpacing:1.5)),const SizedBox(height:8),tile('Status AM-PREM','Periksa koneksi layanan',Icons.monitor_heart_outlined,()=>action('/api/premium/status')),tile('Cek API Key','Validasi konfigurasi key di backend',Icons.key_outlined,()=>action('/api/premium/key-check')),tile('Kirim verifikasi','Kirim email untuk verifikasi',Icons.mark_email_unread_outlined,() => showForm('Kirim verifikasi',email,'Email',()=>action('/api/premium/send-link',body:{'email':email.text.trim()}))),tile('Konfirmasi verifikasi','Masukkan tautan dari email',Icons.verified_outlined,()=>showForm('Konfirmasi tautan',link,'Link verifikasi lengkap',()=>action('/api/premium/verify-apply',body:{'rawLink':link.text.trim()}))),if(message.isNotEmpty)Padding(padding:const EdgeInsets.only(top:14),child:Container(padding:const EdgeInsets.all(14),decoration:BoxDecoration(color:const Color(0xFF1F2937),borderRadius:BorderRadius.circular(12)),child:Text(message))),if(busy)const Padding(padding:EdgeInsets.all(16),child:Center(child:CircularProgressIndicator())),const SizedBox(height:20),Text('API key dan cookie sesi disimpan di backend, bukan di aplikasi.',textAlign:TextAlign.center,style:TextStyle(color:Colors.grey.shade500,fontSize:12))])));
 Widget metric(String title,String value)=>Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(value,style:const TextStyle(fontSize:25,fontWeight:FontWeight.bold)),Text(title,style:TextStyle(color:Colors.white.withValues(alpha:.75)))]);
 void showForm(String title,TextEditingController controller,String label,VoidCallback submit){showDialog(context:context,builder:(ctx)=>AlertDialog(title:Text(title),content:TextField(controller:controller,decoration:InputDecoration(labelText:label,border:const OutlineInputBorder()),maxLines:2),actions:[TextButton(onPressed:()=>Navigator.pop(ctx),child:const Text('BATAL')),FilledButton(onPressed:(){Navigator.pop(ctx);submit();},child:const Text('KIRIM'))]));}
}
