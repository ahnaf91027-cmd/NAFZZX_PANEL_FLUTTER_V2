// =====================================================
// NAFZZX PANEL — SERVER.JS
// Node.js 18+ | npm install express
// =====================================================
"use strict";

const express = require("express");
const crypto = require("crypto");
const fs = require("fs");
const path = require("path");

// ================= CONFIG: ISI API KEY DI SINI =================
// Masukkan key aktif milikmu. Jangan taruh API key di HTML.
// Jangan gunakan pergantian key untuk melewati batas kuota penyedia.
const AM_API_KEY = "ISI_API_KEY_AM_PREM_DI_SINI"; // format amp_...; jangan masukkan ke HTML
const AM_SESSION_COOKIE = "ISI_COOKIE_SESSION_DI_SINI"; // endpoint verify pada docs memerlukan Cookie: session
const AM_API_ORIGIN = "https://am-prem.noctyra.my.id";
const AM_API_V1 = `${AM_API_ORIGIN}/api/v1`;

// Akun owner awal. Nilai ini disinkronkan ke database saat server mulai.
// Ganti lewat environment variable jika ingin mengubah kredensial.
const OWNER_USERNAME = process.env.OWNER_USERNAME || "Nafzzx";
const OWNER_PASSWORD = process.env.OWNER_PASSWORD || "bilqis";
const PORT = Number(process.env.PORT) || 3255;

const app = express();
app.disable("x-powered-by");
app.use(express.json({ limit: "30kb" }));

const DATA_DIR = path.join(__dirname, "data");
const DB_FILE = path.join(DATA_DIR, "users.json");
const PUBLIC_DIR = path.join(__dirname, "public");
fs.mkdirSync(DATA_DIR, { recursive: true });

function hashPassword(password, salt = crypto.randomBytes(16).toString("hex")) {
  return {
    salt,
    hash: crypto.scryptSync(password, salt, 64).toString("hex")
  };
}
function verifyPassword(password, user) {
  if (!user.passwordSalt || !user.passwordHash) return false;
  const actual = crypto.scryptSync(password, user.passwordSalt, 64);
  const expected = Buffer.from(user.passwordHash, "hex");
  return actual.length === expected.length && crypto.timingSafeEqual(actual, expected);
}
function readDB() {
  try {
    const parsed = JSON.parse(fs.readFileSync(DB_FILE, "utf8"));
    return Array.isArray(parsed.users) ? parsed : { users: [] };
  } catch {
    return { users: [] };
  }
}
function writeDB(db) {
  const tmp = DB_FILE + ".tmp";
  fs.writeFileSync(tmp, JSON.stringify(db, null, 2), { mode: 0o600 });
  fs.renameSync(tmp, DB_FILE);
}
function safeUser(user) {
  return { id: user.id, username: user.username, role: user.role };
}

// Ensure owner exists and reset owner password to configured password.
// This fixes old JSON databases where the password was stored in a different format.
function ensureOwner() {
  const db = readDB();
  let owner = db.users.find(u => String(u.username).toLowerCase() === OWNER_USERNAME.toLowerCase());
  const credentials = hashPassword(OWNER_PASSWORD);
  if (!owner) {
    owner = {
      id: crypto.randomUUID(),
      username: OWNER_USERNAME,
      role: "owner",
      passwordSalt: credentials.salt,
      passwordHash: credentials.hash,
      createdAt: new Date().toISOString()
    };
    db.users.push(owner);
  } else {
    owner.role = "owner";
    owner.passwordSalt = credentials.salt;
    owner.passwordHash = credentials.hash;
  }
  writeDB(db);
}
ensureOwner();

const sessions = new Map();
const SESSION_MAX_AGE = 24 * 60 * 60 * 1000;
const ONLINE_WINDOW = 2 * 60 * 1000;

function onlineCount() {
  const now = Date.now();
  const active = new Set();
  for (const [token, s] of sessions) {
    if (now - s.createdAt > SESSION_MAX_AGE || now - s.lastSeen > ONLINE_WINDOW) {
      sessions.delete(token);
    } else active.add(s.userId);
  }
  return active.size;
}
function auth(req, res, next) {
  const match = (req.headers.authorization || "").match(/^Bearer\s+(.+)$/i);
  if (!match) return res.status(401).json({ success: false, message: "Silakan login terlebih dahulu." });
  const session = sessions.get(match[1]);
  if (!session || Date.now() - session.createdAt > SESSION_MAX_AGE) {
    sessions.delete(match[1]);
    return res.status(401).json({ success: false, message: "Sesi berakhir. Silakan login kembali." });
  }
  const user = readDB().users.find(u => u.id === session.userId);
  if (!user) {
    sessions.delete(match[1]);
    return res.status(401).json({ success: false, message: "Akun tidak ditemukan." });
  }
  session.lastSeen = Date.now();
  req.token = match[1];
  req.user = user;
  next();
}
function roles(...allowed) {
  return (req, res, next) => {
    if (!allowed.includes(req.user.role)) {
      return res.status(403).json({ success: false, message: "Akses ditolak untuk role ini." });
    }
    next();
  };
}
function configuredKey() {
  const key = String(AM_API_KEY || "").trim();
  return key && !key.startsWith("ISI_API_KEY_") && !key.startsWith("ISI_API_KEY_AM_") && key.length > 12 ? key : null;
}
function hasSessionCookie() {
  const value = String(AM_SESSION_COOKIE || "").trim();
  return value && !value.startsWith("ISI_COOKIE_") ? value : null;
}
async function upstreamRequest(url, method, body, { useApiKey = false, useSession = false, timeoutMs = 15000 } = {}) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const headers = { Accept: "application/json" };
    if (body !== undefined) headers["Content-Type"] = "application/json";
    if (useApiKey) {
      const key = configuredKey();
      if (!key) throw new Error("API_KEY_NOT_CONFIGURED");
      headers.Authorization = `Bearer ${key}`;
    }
    if (useSession) {
      const cookie = hasSessionCookie();
      if (!cookie) throw new Error("SESSION_COOKIE_NOT_CONFIGURED");
      headers.Cookie = cookie;
    }
    const response = await fetch(url, {
      method, headers,
      ...(body !== undefined ? { body: JSON.stringify(body) } : {}),
      signal: controller.signal
    });
    const data = await response.json().catch(() => ({}));
    return { response, data };
  } finally { clearTimeout(timer); }
}
function upstreamError(res, response, data) {
  const message = data?.message || data?.error || `API AM-PREM mengembalikan HTTP ${response.status}.`;
  return res.status(response.status === 429 ? 429 : (response.status >= 400 && response.status < 500 ? response.status : 502))
    .json({ success: false, message });
}

// Login
app.post("/api/login", (req, res) => {
  const username = String(req.body?.username || "").trim();
  const password = String(req.body?.password || "");
  if (!username || !password) return res.status(400).json({ success: false, message: "Username dan password wajib diisi." });

  const user = readDB().users.find(u => u.username.toLowerCase() === username.toLowerCase());
  if (!user || !verifyPassword(password, user)) {
    return res.status(401).json({ success: false, message: "Username atau password salah." });
  }
  const token = crypto.randomBytes(32).toString("hex");
  sessions.set(token, { userId: user.id, createdAt: Date.now(), lastSeen: Date.now() });
  res.json({ success: true, token, user: safeUser(user) });
});

app.get("/api/me", auth, (req, res) => res.json({ success: true, user: safeUser(req.user) }));
app.post("/api/logout", auth, (req, res) => {
  sessions.delete(req.token);
  res.json({ success: true, message: "Berhasil keluar." });
});

// Stats: only owner sees registered account total; all roles see online users.
app.get("/api/stats", auth, (req, res) => {
  const data = { success: true, onlineUsers: onlineCount(), role: req.user.role };
  if (req.user.role === "owner") data.totalUsers = readDB().users.length;
  res.json(data);
});

// Owner sees list of accounts.
app.get("/api/users", auth, roles("owner"), (req, res) => {
  const users = readDB().users.map(safeUser);
  res.json({ success: true, users });
});

// Owner can create member/reseller. Reseller can create member only.
app.post("/api/users", auth, roles("owner", "reseller"), (req, res) => {
  const username = String(req.body?.username || "").trim();
  const password = String(req.body?.password || "");
  const role = String(req.body?.role || "member").toLowerCase();

  if (!/^[a-zA-Z0-9_-]{3,24}$/.test(username)) {
    return res.status(400).json({ success: false, message: "Username 3–24 karakter: huruf, angka, _ atau -." });
  }
  if (password.length < 8 || password.length > 128) {
    return res.status(400).json({ success: false, message: "Password harus 8–128 karakter." });
  }
  if (!["member", "reseller"].includes(role)) {
    return res.status(400).json({ success: false, message: "Role hanya member atau reseller." });
  }
  if (req.user.role === "reseller" && role !== "member") {
    return res.status(403).json({ success: false, message: "Reseller hanya boleh membuat akun member." });
  }

  const db = readDB();
  if (db.users.some(u => u.username.toLowerCase() === username.toLowerCase())) {
    return res.status(409).json({ success: false, message: "Username sudah digunakan." });
  }
  const credentials = hashPassword(password);
  const user = {
    id: crypto.randomUUID(), username, role,
    passwordSalt: credentials.salt, passwordHash: credentials.hash,
    createdBy: req.user.id, createdAt: new Date().toISOString()
  };
  db.users.push(user);
  writeDB(db);
  res.status(201).json({ success: true, message: `Akun ${username} berhasil dibuat.`, user: safeUser(user) });
});

// Only owner can delete non-owner accounts, by ID.
app.delete("/api/users/:id", auth, roles("owner"), (req, res) => {
  const db = readDB();
  const target = db.users.find(u => u.id === req.params.id);
  if (!target) return res.status(404).json({ success: false, message: "Akun tidak ditemukan." });
  if (target.role === "owner") return res.status(403).json({ success: false, message: "Akun owner tidak dapat dihapus." });
  db.users = db.users.filter(u => u.id !== target.id);
  writeDB(db);
  for (const [token, s] of sessions) if (s.userId === target.id) sessions.delete(token);
  res.json({ success: true, message: "Akun berhasil dihapus." });
});

// Cek API key pada endpoint AM-PREM v1 yang memang menggunakan Bearer token.
app.get("/api/premium/status", auth, async (req, res) => {
  try {
    const { response, data } = await upstreamRequest(`${AM_API_V1}/status`, "GET");
    if (!response.ok || !data.success) return upstreamError(res, response, data);
    res.json({ success: true, message: data.message || "AM-PREM online.", data: data.data || {} });
  } catch (err) {
    res.status(502).json({ success: false, message: err.name === "AbortError" ? "AM-PREM timeout." : "Tidak bisa menghubungi AM-PREM." });
  }
});
app.get("/api/premium/key-check", auth, async (req, res) => {
  if (!configuredKey()) return res.status(503).json({ success: false, message: "Isi AM_API_KEY di bagian atas server.js lalu restart." });
  try {
    const { response, data } = await upstreamRequest(`${AM_API_V1}/user`, "GET", undefined, { useApiKey: true });
    if (!response.ok || !data.success) return upstreamError(res, response, data);
    const profile = data.data || {};
    res.json({ success: true, message: "API key diterima oleh endpoint /api/v1/user.", profile: { id: profile.id, name: profile.name, email: profile.email, role: profile.role } });
  } catch (err) {
    res.status(502).json({ success: false, message: err.message === "API_KEY_NOT_CONFIGURED" ? "API key belum diisi." : "Gagal memeriksa API key AM-PREM." });
  }
});

// Endpoint verify pada dokumentasi AM-PREM menggunakan Cookie: session.
// API key Bearer saja tidak menggantikan sesi web untuk endpoint ini.
app.post("/api/premium/send-link", auth, async (req, res) => {
  const email = String(req.body?.email || "").trim().toLowerCase();
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return res.status(400).json({ success: false, message: "Email tidak valid." });
  if (!hasSessionCookie()) return res.status(503).json({ success: false, message: "AM_SESSION_COOKIE belum diisi. Dokumentasi AM-PREM menandai /api/verify/send sebagai endpoint yang memerlukan Cookie: session; API key Bearer saja tidak cukup." });
  try {
    const { response, data } = await upstreamRequest(`${AM_API_ORIGIN}/api/verify/send`, "POST", { email }, { useSession: true, timeoutMs: 20000 });
    if (!response.ok || !data.success) return upstreamError(res, response, data);
    res.json({ success: true, message: data.message || "Email verifikasi dikirim. Periksa inbox/spam." });
  } catch (err) {
    res.status(502).json({ success: false, message: err.name === "AbortError" ? "AM-PREM timeout." : "Tidak bisa menghubungi endpoint verifikasi AM-PREM." });
  }
});
app.post("/api/premium/verify-apply", auth, async (req, res) => {
  const link = String(req.body?.rawLink || "").trim();
  if (!/^https?:\/\//i.test(link)) return res.status(400).json({ success: false, message: "Masukkan link verifikasi lengkap dari email." });
  if (!hasSessionCookie()) return res.status(503).json({ success: false, message: "AM_SESSION_COOKIE belum diisi. Endpoint /api/verify/confirm memerlukan Cookie: session." });
  try {
    const { response, data } = await upstreamRequest(`${AM_API_ORIGIN}/api/verify/confirm`, "POST", { link }, { useSession: true, timeoutMs: 25000 });
    if (!response.ok || !data.success) return upstreamError(res, response, data);
    res.json({ success: true, message: data.message || "Verifikasi diproses.", data: data.data || {} });
  } catch (err) {
    res.status(502).json({ success: false, message: err.name === "AbortError" ? "AM-PREM timeout." : "Tidak bisa menghubungi endpoint konfirmasi AM-PREM." });
  }
});

app.get("/api/health", (req, res) => res.json({
  success: true, service: "NAFZZX PANEL", apiKeyConfigured: Boolean(configuredKey()),
  sessionCookieConfigured: Boolean(hasSessionCookie()), timestamp: new Date().toISOString()
}));

app.use(express.static(PUBLIC_DIR));
app.use((req, res) => {
  if (req.path.startsWith("/api/")) return res.status(404).json({ success: false, message: "Endpoint API tidak ditemukan." });
  res.sendFile(path.join(PUBLIC_DIR, "index.html"));
});
app.use((err, req, res, next) => {
  console.error("Server error:", err.message);
  if (res.headersSent) return next(err);
  res.status(500).json({ success: false, message: "Kesalahan internal server." });
});

app.listen(PORT, "0.0.0.0", () => {
  console.log(`NAFZZX PANEL aktif pada port ${PORT}`);
  console.log(`Owner login: ${OWNER_USERNAME}`);
  console.log(`AM-PREM API key: ${configuredKey() ? "TERDETEKSI" : "BELUM DIISI"}`);
  console.log(`AM-PREM session cookie: ${hasSessionCookie() ? "TERDETEKSI" : "BELUM DIISI"}`);
});
