# NAFZZX PANEL v2.1 — AM-PREM

## Isi konfigurasi di bagian atas `server.js`
- `AM_API_KEY`: API key format `amp_...` untuk endpoint `/api/v1/user` dan `/api/v1/status`.
- `AM_SESSION_COOKIE`: cookie sesi web AM-PREM dengan format nilai cookie session, karena dokumentasi yang diberikan menandai `/api/verify/send` dan `/api/verify/confirm` sebagai Auth Required dengan `Cookie: session`. API key Bearer tidak otomatis menggantikan cookie sesi.

Jangan pernah memasukkan API key atau cookie ke `public/index.html`, dan jangan membagikan keduanya. Key yang sempat dibagikan di chat sebaiknya diregenerasi.

## Jalankan
1. Ekstrak ZIP.
2. Isi `AM_API_KEY` dan, jika memang berwenang menggunakannya, `AM_SESSION_COOKIE` di bagian atas `server.js`.
3. `npm install`
4. `npm start`

Login awal: `Nafzzx` / `bilqis`. Ganti password owner untuk penggunaan produksi dengan environment variable `OWNER_PASSWORD`.

## Catatan API
ZIP ini memakai base URL `https://am-prem.noctyra.my.id`. API key diperiksa melalui `GET /api/v1/user`. Flow verifikasi memakai endpoint yang terlihat di screenshot: `POST /api/verify/send` dengan `{email}` dan `POST /api/verify/confirm` dengan `{link}`. Screenshot tidak menunjukkan endpoint terpisah untuk apply premium, jadi project tidak mengarang endpoint tersebut; konfirmasi akan mengikuti respons API.
